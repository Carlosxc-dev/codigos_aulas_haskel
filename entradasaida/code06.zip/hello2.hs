main = do
  putStrLn "Ola! Qual o seu nome?"
  name <- getLine
  putStrLn ("Seja bem vindo, " ++ name ++ "!")

  
